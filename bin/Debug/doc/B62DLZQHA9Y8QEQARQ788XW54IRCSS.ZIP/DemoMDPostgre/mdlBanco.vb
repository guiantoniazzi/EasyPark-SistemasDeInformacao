﻿Imports Npgsql

Public Class BackEnd
    Public dados As DataTable
    Private sConnectionString As String = "Server=localhost;Port=5432;UserId=postgres;Password=fatec;Database=Loja"

    Public Function LoadGrid(database As String, tabela As String, sql As String) As DataTable
        'Try
        Dim conn As New NpgsqlConnection(sConnectionString)
            conn.Open()
            Dim cmd = conn.CreateCommand
            Dim daTabela As New NpgsqlDataAdapter(sql, conn)
            Dim ds As New DataSet(database)
            daTabela.FillSchema(ds, SchemaType.Source, tabela)
            daTabela.Fill(ds, tabela)
            dados = ds.Tables(tabela)
            cmd.Dispose()
            conn.Close()
        'Catch ex As Exception
        'MsgBox("Erro ao acessar o banco de dados: " & ex.Message)
        'End Try
        Return dados
    End Function
    Public Function LoadProduto() As DataTable
        Try
            Dim conn As New NpgsqlConnection(sConnectionString)
            conn.Open()
            Dim cmd = conn.CreateCommand
            Dim daProduto As New NpgsqlDataAdapter("Select codprod as Código, dsprod as Produto, saldo  from produto order by dsprod", conn)
            Dim ds As New DataSet("loja")
            daProduto.FillSchema(ds, SchemaType.Source, "produto")
            daProduto.Fill(ds, "Produto")
            dados = ds.Tables("Produto")
            cmd.Dispose()
            conn.Close()
        Catch ex As Exception
            MsgBox("Erro ao acessar o banco de dados: " & ex.Message)
        End Try
        Return dados
    End Function


    Public Sub alteraProduto(pcodprod As Integer, pdsprod As String, psaldo As Integer, psldmin As Integer, pprvenda As String, pprcusto As String)

        Dim conn As New NpgsqlConnection(sConnectionString)
        Dim cmd As New NpgsqlCommand
        conn.Open()
        Dim sql = ""
        sql = sql & " Update produto "
        sql = sql & " Set dsprod = " & "'" & pdsprod & "'"
        sql = sql & ", Saldo = " & psaldo
        sql = sql & ", Sldmin = " & psldmin
        sql = sql & ", prvenda = " & "'" & Replace(pprvenda, ",", ".") & "'"
        sql = sql & ", prcusto = " & "'" & Replace(pprcusto, ",", ".") & "'"
        sql = sql & "  where codprod = " & pcodprod
        cmd.Connection = conn
        cmd.CommandText = sql
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub
End Class
