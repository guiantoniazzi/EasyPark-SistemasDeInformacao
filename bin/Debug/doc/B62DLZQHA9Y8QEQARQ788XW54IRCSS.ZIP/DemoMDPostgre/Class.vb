﻿Imports Microsoft.VisualBasic

Public Class CarregaGrid

    Sub conecta() As SQLite.SQLiteConnection
        Try
            sConnectionString = "Data Source=C:\ADSMA2\Demo\Demo\Banco\dbloja.db;Version=3;New=True;Compress=True;"
            'abre a conexão
            Dim oConn As New SQLite.SQLiteConnection(sConnectionString)
            oConn.Open()
            'fecha a conexao
            oConn.Close()
        Catch ex As Exception
            MsgBox("Erro ao acessar o banco de dados SQLite: " & ex.Message)
        End Try

    End Sub

End Class
