﻿Public Class frmProduto
    Dim db As New BackEnd()

    Private Sub btnSair_Click(sender As Object, e As EventArgs) Handles btnSair.Click
        Me.Close()
    End Sub

    Private Sub frmProduto_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnAlterar_Click(sender As Object, e As EventArgs) Handles btnAlterar.Click
        db.alteraProduto(txtCodigo.Text, txtDescricao.Text, txtSaldo.Text, txtSaldoMinimo.Text, txtPrecoVenda.Text, txtPrecoCusto.Text)
    End Sub

    Private Sub btnExcluir_Click(sender As Object, e As EventArgs) Handles btnExcluir.Click
        If MsgBox("Confirma a exclusão deste produto?", vbYesNo, "PRODUTO") = vbYes Then
            MsgBox("apagar")
        End If


    End Sub
End Class