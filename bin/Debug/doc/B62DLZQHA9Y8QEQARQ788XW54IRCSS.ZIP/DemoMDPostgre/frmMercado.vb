﻿Imports Npgsql
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frmMercado
    Dim db As New BackEnd()
    Private Sub GrdProduto_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles GrdProduto.CellContentClick
        Dim i As Integer
        i = GrdProduto.CurrentRow.Index
        frmProduto.txtCodigo.Text = GrdProduto.Item(0, i).Value
        frmProduto.txtDescricao.Text = GrdProduto.Item(1, i).Value
        frmProduto.txtSaldo.Text = GrdProduto.Item(2, i).Value
        frmProduto.txtSaldoMinimo.Text = GrdProduto.Item(3, i).Value
        frmProduto.txtPrecoVenda.Text = GrdProduto.Item(4, i).Value
        frmProduto.txtPrecoCusto.Text = GrdProduto.Item(5, i).Value
        frmProduto.Show()
    End Sub

    Private Sub frmMercado_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        GrdProduto.DataSource = db.LoadGrid("Loja", "Produto", "select codprod as Código, dsprod as Descrição, saldo  as Saldo, sldmin as Mínimo, prvenda as Preço, prcusto as Custo from produto")
    End Sub

    Private Sub btnSair_Click(sender As Object, e As EventArgs) Handles btnSair.Click
        Me.Close()
    End Sub

    Private Sub frmMercado_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
