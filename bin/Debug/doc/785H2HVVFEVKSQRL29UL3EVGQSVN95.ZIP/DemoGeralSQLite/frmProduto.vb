﻿Imports System.Data.SQLite
Public Class frmProduto
    Public dados As DataTable
    Private sConnectionString As String = "Data Source=d:\ADS20231S\DemoGeralSQLite\Banco\dbloja.db;New=True;Compress=True;"

    Private Sub btnSair_Click(sender As Object, e As EventArgs) Handles btnSair.Click
        Me.Close()
    End Sub
    Private Sub btnAlterar_Click(sender As Object, e As EventArgs) Handles btnAlterar.Click
        alteraProduto(txtCodigo.Text, txtDescricao.Text, txtSaldo.Text, txtSaldoMinimo.Text, txtPrecoVenda.Text, txtPrecoCusto.Text)
    End Sub

    Private Sub btnExcluir_Click(sender As Object, e As EventArgs) Handles btnExcluir.Click
        If MsgBox("Confirma a exclusão deste produto?", vbYesNo, "PRODUTO") = vbYes Then
            ExcluiProduto(txtCodigo.Text)
        End If
    End Sub

    Public Sub alteraProduto(pcodprod As Integer, pdsprod As String, psaldo As Integer, psldmin As Integer, pprvenda As String, pprcusto As String)
        Dim conn As New SQLiteConnection(sConnectionString)
        Dim cmd As New SQLiteCommand
        conn.Open()
        Dim sql = ""
        sql = sql & " Update produto "
        sql = sql & " Set dsprod = " & "'" & pdsprod & "'"
        sql = sql & ", Saldo = " & psaldo
        sql = sql & ", Sldmin = " & psldmin
        sql = sql & ", prvenda = " & "'" & Replace(pprvenda, ",", ".") & "'"
        sql = sql & ", prcusto = " & "'" & Replace(pprcusto, ",", ".") & "'"
        sql = sql & "  where codprod = " & pcodprod
        cmd.Connection = conn
        cmd.CommandText = sql
        cmd.ExecuteNonQuery()
        conn.Close()
        Me.Close()
    End Sub

    Public Sub ExcluiProduto(pcodprod As Integer)
        Dim conn As New SQLiteConnection(sConnectionString)
        Dim cmd As New SQLiteCommand
        conn.Open()
        Dim sql = ""
        sql = sql & " Delete from produto where codprod = " & pcodprod
        cmd.Connection = conn
        cmd.CommandText = sql
        cmd.ExecuteNonQuery()
        conn.Close()
        Me.Close()
    End Sub
End Class