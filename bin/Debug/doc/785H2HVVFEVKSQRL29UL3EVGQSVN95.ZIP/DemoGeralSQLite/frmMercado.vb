﻿Imports System.Data.SQLite
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frmMercado

    Public dados As DataTable
    Private sConnectionString As String = "Data Source=D:\ADS20231S\DemoGeralSQLite\Banco\dbloja.db;New=True;Compress=True;"

    Private Sub GrdProduto_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles GrdProduto.CellContentClick
        Dim i As Integer
        i = GrdProduto.CurrentRow.Index
        frmProduto.txtCodigo.Text = GrdProduto.Item(0, i).Value
        frmProduto.txtDescricao.Text = GrdProduto.Item(1, i).Value
        frmProduto.txtSaldo.Text = GrdProduto.Item(2, i).Value
        frmProduto.txtSaldoMinimo.Text = GrdProduto.Item(3, i).Value
        frmProduto.txtPrecoVenda.Text = GrdProduto.Item(4, i).Value
        frmProduto.txtPrecoCusto.Text = GrdProduto.Item(5, i).Value
        frmProduto.Show()
    End Sub

    Private Sub frmMercado_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        GrdProduto.DataSource = LoadGrid("Loja", "Produto", "Select codprod as Código, dsprod as Produto, saldo, sldmin as Mínimo, prvenda, prcusto from produto")
    End Sub

    Public Function LoadProduto() As DataTable

        Try
            Dim conn As New SQLiteConnection(sConnectionString)
            conn.Open()
            Dim cmd = conn.CreateCommand
            Dim daProduto As New SQLite.SQLiteDataAdapter("Select codprod as Código, dsprod as Produto, saldo  from produto order by dsprod", conn)
            Dim ds As New DataSet("loja")
            daProduto.FillSchema(ds, SchemaType.Source, "produto")
            daProduto.Fill(ds, "Produto")
            dados = ds.Tables("Produto")
            cmd.Dispose()
            conn.Close()
        Catch ex As Exception
            MsgBox("Erro ao acessar o banco de dados SQLite: " & ex.Message)
        End Try
        Return dados
    End Function

    Public Function LoadGrid(database As String, tabela As String, sql As String) As DataTable
        Try
            Dim conn As New SQLiteConnection(sConnectionString)
            conn.Open()
            Dim cmd = conn.CreateCommand
            Dim daTabela As New SQLite.SQLiteDataAdapter(sql, conn)
            Dim ds As New DataSet(database)
            daTabela.FillSchema(ds, SchemaType.Source, tabela)
            daTabela.Fill(ds, tabela)
            dados = ds.Tables(tabela)
            cmd.Dispose()
            conn.Close()
        Catch ex As Exception
            MsgBox("Erro ao acessar o banco de dados SQLite: " & ex.Message)
        End Try
        Return dados
    End Function

End Class
