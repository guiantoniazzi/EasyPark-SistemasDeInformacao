﻿Imports Microsoft.VisualBasic

Public Class BackEnd

    Public Sub mensagem()
        msgbox("acessei")
    End Sub

End Class
