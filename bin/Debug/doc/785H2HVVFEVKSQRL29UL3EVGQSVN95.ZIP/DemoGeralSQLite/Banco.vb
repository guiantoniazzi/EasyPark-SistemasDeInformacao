﻿Imports Microsoft.VisualBasic

Public Class Banco
    Public dados As DataTable
    Private sConnectionString As String = "Data Source=E:\ADS20231S\DemoGeralSQLite\Banco\dbloja.db;New=True;Compress=True;"
End Class
